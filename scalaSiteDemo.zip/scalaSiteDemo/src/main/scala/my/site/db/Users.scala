package dbExamples

import scalikejdbc._

import java.util.Date

object Users{

  /* def hasPosts(name:String):Boolean = {
     implicit val session = AutoSession
     sql"""
          SELECT *
          FROM Hoomans
          WHERE name = $name AND EXISTS (
             SELECT * FROM Relations WHERE HoomanId = Hoomans.id
          )
        """.map(x => x).single().apply().nonEmpty
   }*/

  def searchUser(name:String):Seq[User] = {//None Some(4)
    implicit val session = AutoSession
    sql"""
         SELECT *
         FROM Users
         WHERE name LIKE '%$name%'
         """.map(rs =>User(rs.int("id"), rs.string("name"), rs.date("registdate"), rs.string("aboutuser"))).list().apply()
  }


  def register(name:String, status:String) :Unit = {
    implicit val session = AutoSession
    //"); drop table Doges"
    sql"""insert into Users(name, registdate, aboutuser) VALUES($name,${new Date()} , $status)""".update().apply()
  }

 /* def allUsers():Seq[User] = {
    implicit val session = AutoSession
    sql"""select * from Users"""
      .map(rs => Users(rs.int("id"), rs.string("name"), rs.date("date"), rs.string("aboutuser"))).apply()
  }*/

   def AllUsers():Seq[User] = {
     implicit val session = AutoSession
     sql"""select * from Users"""
       .map(rs => User(rs.int("id"), rs.string("name"), rs.date("registdate"), rs.string("aboutuser"))).list().apply()
   }

  /* def getDogs(id: Int): Seq[Doge] = {
     implicit val session = AutoSession
     sql"""SELECT * FROM Doges
       WHERE EXISTS (
             SELECT * FROM Relations WHERE HoomanId = $id AND Doges.id = DogeId
          )""".map(rs => Doge(rs.int("id"), rs.string("name")))
       .list().apply()
   }*/

  //  getDogs(23)
  //  new Hooman(23, "we").myDogs
}


case class User(id:Int, name:String, registdate:Date, aboutuser:String)
