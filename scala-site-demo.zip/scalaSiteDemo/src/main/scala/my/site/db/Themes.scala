package dbExamples
import scalikejdbc._

object Themes {
  def addTheme(name:String, about:String) :Unit = {
    implicit val session = AutoSession
    sql"""insert into Themes(name, about) VALUES($name, $about)""".update().apply
  }

  def Allthemes():Seq[Theme] = {
    implicit val session = AutoSession
    sql"""
         SELECT *
         FROM Themes

         """.map(rs =>Theme(rs.int("id"), rs.string("name"), rs.string("abouttheme"))).list().apply()
  }

  def findTheme(searchword:String):Seq[Theme] = {
    implicit val session = AutoSession
    sql"""
         SELECT *
         FROM Themes
         WHERE about LIKE '%$searchword%'
         """.map(rs =>Theme(rs.int("id"), rs.string("name"), rs.string("abouttheme"))).list().apply()
  }

}

case class Theme(id:Int, name:String, about:String)