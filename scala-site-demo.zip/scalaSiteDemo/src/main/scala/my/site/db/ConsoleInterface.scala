package dbExamples

object ConsoleInterface {
  def run(): Unit = {
    var end = false
    while (!end) {
      println("WELCOME ПРАВОСЛАВНОЯ ДОСКА ОБЪЯВЛЕНИЙ E-блог")
      println("1) ADD NEW USER")
      println("2) ADD NEW THEME")
      println("3) ADD RELATION")
      println("4) SHOW ALL THEMES")
      println("5) IN PROCES...")
      println("6) SHOW ALL USERS")
      scala.io.StdIn.readInt() match {
        case 1 =>
          println("Add HOOMAN ")

          Users.register(scala.io.StdIn.readLine(), scala.io.StdIn.readLine())
        case 2 =>
          println("Add THEME ")
          Themes.addTheme(scala.io.StdIn.readLine(), scala.io.StdIn.readLine())
        case 3 =>
          println("add POST")
           scala.io.StdIn.readLine()
           scala.io.StdIn.readLine()
            Posts.writePost( scala.io.StdIn.readInt(), scala.io.StdIn.readInt(), scala.io.StdIn.readLine())

        case 4 =>
          Themes.Allthemes().foreach(println)
        case 6 =>
          Users.AllUsers().foreach(println)
     /*   case 5 =>
          val hoomanName = scala.io.StdIn.readLine()
          for(h <- Hooman.reqHooman(hoomanName);
              d <- h.myDogs){
            println(d) */
          }
      }
    }

}
